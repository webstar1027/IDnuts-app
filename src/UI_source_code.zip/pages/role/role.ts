import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the RolePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-role',
  templateUrl: 'role.html',
})
export class RolePage {
    roles = [
                [
                    {
                      imageUrl: 'assets/img/role/parents.jpg',
                      title: 'Parents',
                      value: 1
                    },
                    {
                      imageUrl: 'assets/img/role/shipping.png',
                      title: 'Shippers',
                      value: 2
                    }
                ],

                [
                    {
                      imageUrl: 'assets/img/role/service_provider.png',
                      title: 'Service Providers',
                      value: 3
                    },
                    {
                      imageUrl: 'assets/img/role/dating.png',
                      title: 'Dating',
                      value: 4
                    }
                ]

    ];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RolePage');
  }
  fun (a) {
    this.navCtrl.push('SignupPage',{a:a})
    //  this.navCtrl.setRoot('SignupPage',{a:a})
  }
}
