# Tabs

Tabs is a common tabbed layout.
