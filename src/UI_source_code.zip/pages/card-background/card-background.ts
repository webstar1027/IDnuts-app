import { Component } from '@angular/core';
import { NavController, IonicPage ,LoadingController,MenuController,ToastController} from 'ionic-angular';
import { Api } from "../../providers/api/api";
import { InAppBrowser } from "@ionic-native/in-app-browser";

@IonicPage()
@Component({
  selector: 'page-card-background',
  templateUrl: 'card-background.html'
})
export class CardBackgroundPage {
  offers:any;
  cards = [
    {
      imageUrl: 'assets/img/card/card-saopaolo.png',
      title: 'Dummy',
      subtitle: 'This will be changed'
    },
    {
      imageUrl: 'assets/img/card/card-amsterdam.png',
      title: 'Windows',
      subtitle: 'Need your Help to change it'
    },
    {
      imageUrl: 'assets/img/card/card-sf.png',
      title: 'Please Guide',
      subtitle: 'What should be on dashboard'
    },
    {
      imageUrl: 'assets/img/card/card-madison.png',
      title: 'Books',
      subtitle: 'its dashboard'
    }];

  constructor(public menu: MenuController,public navCtrl: NavController,public api: Api, public loadingCtrl: LoadingController,public browser: InAppBrowser,public toastCtrl: ToastController) {
      this.menu.enable(true);
  }

  cardTapped(url) {
    console.log(url);
  }

}
