import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VeiwinfoPage } from './veiwinfo';

@NgModule({
  declarations: [
    VeiwinfoPage,
  ],
  imports: [
    IonicPageModule.forChild(VeiwinfoPage),
  ],
})
export class VeiwinfoPageModule {}
