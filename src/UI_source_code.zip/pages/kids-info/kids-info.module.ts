import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { KidsInfoPage } from './kids-info';

@NgModule({
  declarations: [
    KidsInfoPage,
  ],
  imports: [
    IonicPageModule.forChild(KidsInfoPage),
  ],
})
export class KidsInfoPageModule {}
